import { showInitialMenu } from './js/views.js';
import { showUserHistory } from './js/userHistory.js';

document.addEventListener('DOMContentLoaded', () => {
    showInitialMenu();
});

